DROP DATABASE IF EXISTS sistema_projetos;
CREATE DATABASE sistema_projetos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_projetos;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_completo VARCHAR(120) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    email VARCHAR(120) NOT NULL,
    cargo VARCHAR(80),
    login VARCHAR(60) NOT NULL UNIQUE,
    senha VARCHAR(100) NOT NULL,
    perfil VARCHAR(30) NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE projetos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    descricao TEXT,
    data_inicio DATE NOT NULL,
    data_termino_prevista DATE,
    status VARCHAR(30) NOT NULL,
    gerente_id INT NOT NULL,
    entregavel_previsto VARCHAR(180),
    CONSTRAINT fk_projeto_gerente FOREIGN KEY (gerente_id) REFERENCES usuarios(id)
);

CREATE TABLE equipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    descricao TEXT
);

CREATE TABLE equipe_projetos (
    equipe_id INT NOT NULL,
    projeto_id INT NOT NULL,
    PRIMARY KEY (equipe_id, projeto_id),
    CONSTRAINT fk_equipe_projetos_equipe FOREIGN KEY (equipe_id) REFERENCES equipes(id) ON DELETE CASCADE,
    CONSTRAINT fk_equipe_projetos_projeto FOREIGN KEY (projeto_id) REFERENCES projetos(id) ON DELETE CASCADE
);

CREATE TABLE membros_equipe (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipe_id INT NOT NULL,
    usuario_id INT NOT NULL,
    funcao VARCHAR(80),
    CONSTRAINT fk_membro_equipe FOREIGN KEY (equipe_id) REFERENCES equipes(id) ON DELETE CASCADE,
    CONSTRAINT fk_membro_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE tarefas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(140) NOT NULL,
    descricao TEXT,
    projeto_id INT NOT NULL,
    responsavel_id INT NOT NULL,
    prazo DATE,
    status VARCHAR(30) NOT NULL,
    observacoes TEXT,
    entregavel VARCHAR(180),
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_tarefa_projeto FOREIGN KEY (projeto_id) REFERENCES projetos(id) ON DELETE CASCADE,
    CONSTRAINT fk_tarefa_responsavel FOREIGN KEY (responsavel_id) REFERENCES usuarios(id)
);

INSERT INTO usuarios (nome_completo, cpf, email, cargo, login, senha, perfil, ativo) VALUES
('Vinicius Teo', '000.000.000-00', 'vinicius@email.com', 'Administrador do Sistema', 'admin', '123456', 'Administrador', TRUE),
('Mariana Gerente', '111.111.111-11', 'gerente@email.com', 'Gerente de Projetos', 'gerente', '123456', 'Gerente', TRUE),
('Carlos Colaborador', '222.222.222-22', 'colaborador@email.com', 'Analista de Projetos', 'colab', '123456', 'Colaborador', TRUE);

INSERT INTO projetos (nome, descricao, data_inicio, data_termino_prevista, status, gerente_id, entregavel_previsto) VALUES
('Sistema Interno A3', 'Projeto acadêmico para controle de usuários, projetos, equipes e tarefas.', '2026-06-03', '2026-06-04', 'Em andamento', 2, 'Sistema Java com banco MySQL'),
('Portal de Relatórios', 'Módulo para acompanhamento de desempenho dos projetos e tarefas.', '2026-06-03', '2026-06-05', 'Planejado', 2, 'Relatórios gerenciais'),
('Documentação Final', 'Organização da documentação e evidências para entrega da A3.', '2026-06-03', '2026-06-04', 'Concluído', 1, 'Pacote final do projeto');

INSERT INTO equipes (nome, descricao) VALUES
('Equipe Desenvolvimento', 'Equipe responsável pelo desenvolvimento em Java e integração com MySQL.'),
('Equipe Gestão', 'Equipe responsável por requisitos, prazos e validação das entregas.'),
('Equipe Documentação', 'Equipe responsável pela documentação e evidências finais.');

INSERT INTO equipe_projetos (equipe_id, projeto_id) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 3);

INSERT INTO membros_equipe (equipe_id, usuario_id, funcao) VALUES
(1, 1, 'Administrador'),
(1, 3, 'Desenvolvimento'),
(2, 2, 'Gerência'),
(3, 1, 'Documentação');

INSERT INTO tarefas (titulo, descricao, projeto_id, responsavel_id, prazo, status, observacoes, entregavel) VALUES
('Definir requisitos do sistema', 'Levantar requisitos funcionais e não funcionais do projeto.', 1, 2, '2026-06-03', 'Concluída', 'Requisitos revisados e validados para a A3.', 'Documento de requisitos'),
('Criar banco de dados', 'Criar tabelas, relacionamentos e dados iniciais no MySQL.', 1, 1, '2026-06-03', 'Concluída', 'Banco sistema_projetos criado com usuários, projetos, equipes e tarefas.', 'Script SQL'),
('Desenvolver telas do sistema', 'Criar interface visual em Java Swing.', 1, 3, '2026-06-04', 'Em andamento', 'Tela de login, dashboard e cadastros em desenvolvimento.', 'Sistema desktop'),
('Montar relatório de desempenho', 'Criar listagens e indicadores de projetos e tarefas.', 2, 2, '2026-06-05', 'Pendente', '', 'Tela de relatórios'),
('Revisar documentação final', 'Conferir README, passo a passo e evidências do sistema.', 3, 1, '2026-06-04', 'Concluída', 'Documentação organizada para apresentação acadêmica.', 'Documentação final');
