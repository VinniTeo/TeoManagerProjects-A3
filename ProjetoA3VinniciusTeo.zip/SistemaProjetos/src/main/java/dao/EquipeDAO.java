package dao;

import model.Equipe;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EquipeDAO {
    private Equipe criarEquipe(ResultSet rs) throws SQLException {
        return new Equipe(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("descricao"),
                rs.getString("projetos_nomes")
        );
    }

    public int contar() throws SQLException {
        String sql = "SELECT COUNT(*) FROM equipes";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public List<Equipe> listar() throws SQLException {
        List<Equipe> lista = new ArrayList<>();
        String sql = "SELECT e.id, e.nome, e.descricao, " +
                "COALESCE(GROUP_CONCAT(DISTINCT p.nome ORDER BY p.nome SEPARATOR ', '), 'Sem projeto vinculado') AS projetos_nomes " +
                "FROM equipes e " +
                "LEFT JOIN equipe_projetos ep ON ep.equipe_id = e.id " +
                "LEFT JOIN projetos p ON p.id = ep.projeto_id " +
                "GROUP BY e.id, e.nome, e.descricao " +
                "ORDER BY e.id DESC";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(criarEquipe(rs));
            }
        }
        return lista;
    }

    public List<Equipe> listarPorProjeto(int projetoId) throws SQLException {
        List<Equipe> lista = new ArrayList<>();
        String sql = "SELECT e.id, e.nome, e.descricao, p.nome AS projetos_nomes " +
                "FROM equipes e " +
                "INNER JOIN equipe_projetos ep ON ep.equipe_id = e.id " +
                "INNER JOIN projetos p ON p.id = ep.projeto_id " +
                "WHERE ep.projeto_id = ? ORDER BY e.nome";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, projetoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(criarEquipe(rs));
            }
        }
        return lista;
    }

    public void salvar(Equipe e) throws SQLException {
        String sql = "INSERT INTO equipes (nome, descricao) VALUES (?, ?)";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getNome());
            ps.setString(2, e.getDescricao());
            ps.executeUpdate();
        }
    }

    public void atualizar(Equipe e) throws SQLException {
        String sql = "UPDATE equipes SET nome=?, descricao=? WHERE id=?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getNome());
            ps.setString(2, e.getDescricao());
            ps.setInt(3, e.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM equipes WHERE id = ?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
