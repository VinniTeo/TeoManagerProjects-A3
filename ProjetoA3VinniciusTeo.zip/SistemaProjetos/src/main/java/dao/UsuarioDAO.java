package dao;

import model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    private Usuario criarUsuario(ResultSet rs) throws SQLException {
        return new Usuario(
                rs.getInt("id"),
                rs.getString("nome_completo"),
                rs.getString("cpf"),
                rs.getString("email"),
                rs.getString("cargo"),
                rs.getString("login"),
                rs.getString("senha"),
                rs.getString("perfil"),
                rs.getBoolean("ativo")
        );
    }

    public Usuario autenticar(String login, String senha) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE login = ? AND senha = ? AND ativo = 1";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, login);
            ps.setString(2, senha);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return criarUsuario(rs);
                }
            }
        }
        return null;
    }

    public int contar() throws SQLException {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE ativo = 1";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public List<Usuario> listar() throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios ORDER BY nome_completo";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(criarUsuario(rs));
            }
        }
        return lista;
    }

    public List<Usuario> listarAtivos() throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios WHERE ativo = 1 ORDER BY nome_completo";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(criarUsuario(rs));
            }
        }
        return lista;
    }

    public List<Usuario> listarGerentes() throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios WHERE ativo = 1 AND perfil IN ('Administrador','Gerente') ORDER BY nome_completo";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(criarUsuario(rs));
            }
        }
        return lista;
    }

    public void salvar(Usuario u) throws SQLException {
        String sql = "INSERT INTO usuarios (nome_completo, cpf, email, cargo, login, senha, perfil, ativo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNomeCompleto());
            ps.setString(2, u.getCpf());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getCargo());
            ps.setString(5, u.getLogin());
            ps.setString(6, u.getSenha());
            ps.setString(7, u.getPerfil());
            ps.setBoolean(8, u.isAtivo());
            ps.executeUpdate();
        }
    }

    public void atualizar(Usuario u) throws SQLException {
        String sql = "UPDATE usuarios SET nome_completo=?, cpf=?, email=?, cargo=?, login=?, senha=?, perfil=?, ativo=? WHERE id=?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNomeCompleto());
            ps.setString(2, u.getCpf());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getCargo());
            ps.setString(5, u.getLogin());
            ps.setString(6, u.getSenha());
            ps.setString(7, u.getPerfil());
            ps.setBoolean(8, u.isAtivo());
            ps.setInt(9, u.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        String sql = "UPDATE usuarios SET ativo = 0 WHERE id = ?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
