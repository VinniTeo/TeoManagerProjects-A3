package dao;

import model.Projeto;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ProjetoDAO {
    private LocalDate toLocalDate(Date data) {
        return data == null ? null : data.toLocalDate();
    }

    private Date toSqlDate(LocalDate data) {
        return data == null ? null : Date.valueOf(data);
    }

    private Projeto criarProjeto(ResultSet rs) throws SQLException {
        return new Projeto(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("descricao"),
                toLocalDate(rs.getDate("data_inicio")),
                toLocalDate(rs.getDate("data_termino_prevista")),
                rs.getString("status"),
                rs.getInt("gerente_id"),
                rs.getString("gerente_nome"),
                rs.getString("entregavel_previsto"),
                rs.getString("equipes_nomes")
        );
    }

    public int contar() throws SQLException {
        String sql = "SELECT COUNT(*) FROM projetos";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public int contarPorStatus(String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM projetos WHERE status = ?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public List<Projeto> listar() throws SQLException {
        List<Projeto> lista = new ArrayList<>();
        String sql = "SELECT p.*, u.nome_completo AS gerente_nome, " +
                "COALESCE(GROUP_CONCAT(DISTINCT e.nome ORDER BY e.nome SEPARATOR ', '), 'Sem equipe vinculada') AS equipes_nomes " +
                "FROM projetos p " +
                "LEFT JOIN usuarios u ON u.id = p.gerente_id " +
                "LEFT JOIN equipe_projetos ep ON ep.projeto_id = p.id " +
                "LEFT JOIN equipes e ON e.id = ep.equipe_id " +
                "GROUP BY p.id, p.nome, p.descricao, p.data_inicio, p.data_termino_prevista, p.status, p.gerente_id, p.entregavel_previsto, u.nome_completo " +
                "ORDER BY p.id DESC";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(criarProjeto(rs));
            }
        }
        return lista;
    }

    public int salvar(Projeto p) throws SQLException {
        String sql = "INSERT INTO projetos (nome, descricao, data_inicio, data_termino_prevista, status, gerente_id, entregavel_previsto) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNome());
            ps.setString(2, p.getDescricao());
            ps.setDate(3, toSqlDate(p.getDataInicio()));
            ps.setDate(4, toSqlDate(p.getDataTerminoPrevista()));
            ps.setString(5, p.getStatus());
            ps.setInt(6, p.getGerenteId());
            ps.setString(7, p.getEntregavelPrevisto());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    public void atualizar(Projeto p) throws SQLException {
        String sql = "UPDATE projetos SET nome=?, descricao=?, data_inicio=?, data_termino_prevista=?, status=?, gerente_id=?, entregavel_previsto=? WHERE id=?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNome());
            ps.setString(2, p.getDescricao());
            ps.setDate(3, toSqlDate(p.getDataInicio()));
            ps.setDate(4, toSqlDate(p.getDataTerminoPrevista()));
            ps.setString(5, p.getStatus());
            ps.setInt(6, p.getGerenteId());
            ps.setString(7, p.getEntregavelPrevisto());
            ps.setInt(8, p.getId());
            ps.executeUpdate();
        }
    }

    public void atualizarEquipes(int projetoId, List<Integer> equipesIds) throws SQLException {
        String deletar = "DELETE FROM equipe_projetos WHERE projeto_id = ?";
        String inserir = "INSERT INTO equipe_projetos (equipe_id, projeto_id) VALUES (?, ?)";
        try (Connection con = ConexaoBanco.conectar()) {
            con.setAutoCommit(false);
            try (PreparedStatement ps = con.prepareStatement(deletar)) {
                ps.setInt(1, projetoId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement(inserir)) {
                for (Integer equipeId : equipesIds) {
                    ps.setInt(1, equipeId);
                    ps.setInt(2, projetoId);
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            con.commit();
        }
    }

    public List<Integer> listarEquipeIdsDoProjeto(int projetoId) throws SQLException {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT equipe_id FROM equipe_projetos WHERE projeto_id = ? ORDER BY equipe_id";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, projetoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ids.add(rs.getInt("equipe_id"));
            }
        }
        return ids;
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM projetos WHERE id = ?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
