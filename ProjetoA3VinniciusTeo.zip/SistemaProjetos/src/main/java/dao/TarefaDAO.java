package dao;

import model.Tarefa;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TarefaDAO {
    private LocalDate toLocalDate(Date data) {
        return data == null ? null : data.toLocalDate();
    }

    private Date toSqlDate(LocalDate data) {
        return data == null ? null : Date.valueOf(data);
    }

    private Tarefa criarTarefa(ResultSet rs) throws SQLException {
        return new Tarefa(
                rs.getInt("id"),
                rs.getString("titulo"),
                rs.getString("descricao"),
                rs.getInt("projeto_id"),
                rs.getString("projeto_nome"),
                rs.getInt("responsavel_id"),
                rs.getString("responsavel_nome"),
                toLocalDate(rs.getDate("prazo")),
                rs.getString("status"),
                rs.getString("observacoes"),
                rs.getString("entregavel")
        );
    }

    public int contar() throws SQLException {
        String sql = "SELECT COUNT(*) FROM tarefas";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public int contarPorStatus(String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tarefas WHERE status = ?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public List<Tarefa> listar() throws SQLException {
        return listarComFiltro(0, 0, null);
    }

    public List<Tarefa> listarDoResponsavel(int responsavelId) throws SQLException {
        return listarComFiltro(0, responsavelId, null);
    }

    public List<Tarefa> listarComFiltro(int projetoId, int responsavelId, String status) throws SQLException {
        List<Tarefa> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT t.*, p.nome AS projeto_nome, u.nome_completo AS responsavel_nome ");
        sql.append("FROM tarefas t ");
        sql.append("LEFT JOIN projetos p ON p.id = t.projeto_id ");
        sql.append("LEFT JOIN usuarios u ON u.id = t.responsavel_id WHERE 1=1 ");
        if (projetoId > 0) sql.append("AND t.projeto_id = ? ");
        if (responsavelId > 0) sql.append("AND t.responsavel_id = ? ");
        if (status != null && !status.isBlank() && !status.equals("Todos")) sql.append("AND t.status = ? ");
        sql.append("ORDER BY t.prazo IS NULL, t.prazo ASC, t.id DESC");

        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql.toString())) {
            int i = 1;
            if (projetoId > 0) ps.setInt(i++, projetoId);
            if (responsavelId > 0) ps.setInt(i++, responsavelId);
            if (status != null && !status.isBlank() && !status.equals("Todos")) ps.setString(i++, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(criarTarefa(rs));
            }
        }
        return lista;
    }

    public void salvar(Tarefa t) throws SQLException {
        String sql = "INSERT INTO tarefas (titulo, descricao, projeto_id, responsavel_id, prazo, status, observacoes, entregavel) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, t.getTitulo());
            ps.setString(2, t.getDescricao());
            ps.setInt(3, t.getProjetoId());
            ps.setInt(4, t.getResponsavelId());
            ps.setDate(5, toSqlDate(t.getPrazo()));
            ps.setString(6, t.getStatus());
            ps.setString(7, t.getObservacoes());
            ps.setString(8, t.getEntregavel());
            ps.executeUpdate();
        }
    }

    public void atualizar(Tarefa t) throws SQLException {
        String sql = "UPDATE tarefas SET titulo=?, descricao=?, projeto_id=?, responsavel_id=?, prazo=?, status=?, observacoes=?, entregavel=? WHERE id=?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, t.getTitulo());
            ps.setString(2, t.getDescricao());
            ps.setInt(3, t.getProjetoId());
            ps.setInt(4, t.getResponsavelId());
            ps.setDate(5, toSqlDate(t.getPrazo()));
            ps.setString(6, t.getStatus());
            ps.setString(7, t.getObservacoes());
            ps.setString(8, t.getEntregavel());
            ps.setInt(9, t.getId());
            ps.executeUpdate();
        }
    }

    public void atualizarStatusObservacao(int id, String status, String observacoes) throws SQLException {
        String sql = "UPDATE tarefas SET status=?, observacoes=? WHERE id=?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, observacoes);
            ps.setInt(3, id);
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM tarefas WHERE id = ?";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
