package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RelatorioDAO {
    public List<Object[]> tarefasPorStatus() throws SQLException {
        List<Object[]> dados = new ArrayList<>();
        String sql = "SELECT status, COUNT(*) total FROM tarefas GROUP BY status ORDER BY total DESC";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) dados.add(new Object[]{rs.getString("status"), rs.getInt("total")});
        }
        return dados;
    }

    public List<Object[]> tarefasPorColaborador() throws SQLException {
        List<Object[]> dados = new ArrayList<>();
        String sql = "SELECT u.nome_completo, COUNT(t.id) total, SUM(CASE WHEN t.status='Concluída' THEN 1 ELSE 0 END) concluidas " +
                "FROM usuarios u LEFT JOIN tarefas t ON t.responsavel_id = u.id " +
                "WHERE u.ativo = 1 GROUP BY u.id, u.nome_completo ORDER BY total DESC";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) dados.add(new Object[]{rs.getString(1), rs.getInt(2), rs.getInt(3)});
        }
        return dados;
    }

    public List<Object[]> desempenhoProjetos() throws SQLException {
        List<Object[]> dados = new ArrayList<>();
        String sql = "SELECT p.nome, " +
                "COALESCE(eq.equipes, 'Sem equipe vinculada') AS equipes, " +
                "p.status, COUNT(t.id) tarefas, " +
                "SUM(CASE WHEN t.status='Concluída' THEN 1 ELSE 0 END) concluidas, " +
                "SUM(CASE WHEN t.prazo < CURDATE() AND t.status <> 'Concluída' THEN 1 ELSE 0 END) atrasadas " +
                "FROM projetos p " +
                "LEFT JOIN tarefas t ON t.projeto_id = p.id " +
                "LEFT JOIN (SELECT ep.projeto_id, GROUP_CONCAT(DISTINCT e.nome ORDER BY e.nome SEPARATOR ', ') equipes " +
                "           FROM equipe_projetos ep INNER JOIN equipes e ON e.id = ep.equipe_id GROUP BY ep.projeto_id) eq ON eq.projeto_id = p.id " +
                "GROUP BY p.id, p.nome, eq.equipes, p.status ORDER BY p.nome";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) dados.add(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getInt(6)});
        }
        return dados;
    }

    public List<Object[]> prazosEntregaveis() throws SQLException {
        List<Object[]> dados = new ArrayList<>();
        String sql = "SELECT t.titulo, p.nome projeto, COALESCE(eq.equipes, 'Sem equipe vinculada') equipes, " +
                "u.nome_completo responsavel, t.prazo, t.status, t.entregavel " +
                "FROM tarefas t " +
                "LEFT JOIN projetos p ON p.id=t.projeto_id " +
                "LEFT JOIN usuarios u ON u.id=t.responsavel_id " +
                "LEFT JOIN (SELECT ep.projeto_id, GROUP_CONCAT(DISTINCT e.nome ORDER BY e.nome SEPARATOR ', ') equipes " +
                "           FROM equipe_projetos ep INNER JOIN equipes e ON e.id = ep.equipe_id GROUP BY ep.projeto_id) eq ON eq.projeto_id = p.id " +
                "ORDER BY t.prazo IS NULL, t.prazo ASC";
        try (Connection con = ConexaoBanco.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) dados.add(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getDate(5), rs.getString(6), rs.getString(7)});
        }
        return dados;
    }
}
