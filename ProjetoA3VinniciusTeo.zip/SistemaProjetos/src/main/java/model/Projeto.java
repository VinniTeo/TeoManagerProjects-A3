package model;

import java.time.LocalDate;

public class Projeto {
    private int id;
    private String nome;
    private String descricao;
    private LocalDate dataInicio;
    private LocalDate dataTerminoPrevista;
    private String status;
    private int gerenteId;
    private String gerenteNome;
    private String entregavelPrevisto;
    private String equipesNomes;

    public Projeto() {}

    public Projeto(int id, String nome, String descricao, LocalDate dataInicio, LocalDate dataTerminoPrevista, String status, int gerenteId, String gerenteNome, String entregavelPrevisto, String equipesNomes) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.dataInicio = dataInicio;
        this.dataTerminoPrevista = dataTerminoPrevista;
        this.status = status;
        this.gerenteId = gerenteId;
        this.gerenteNome = gerenteNome;
        this.entregavelPrevisto = entregavelPrevisto;
        this.equipesNomes = equipesNomes;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public LocalDate getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; }
    public LocalDate getDataTerminoPrevista() { return dataTerminoPrevista; }
    public void setDataTerminoPrevista(LocalDate dataTerminoPrevista) { this.dataTerminoPrevista = dataTerminoPrevista; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getGerenteId() { return gerenteId; }
    public void setGerenteId(int gerenteId) { this.gerenteId = gerenteId; }
    public String getGerenteNome() { return gerenteNome; }
    public void setGerenteNome(String gerenteNome) { this.gerenteNome = gerenteNome; }
    public String getEntregavelPrevisto() { return entregavelPrevisto; }
    public void setEntregavelPrevisto(String entregavelPrevisto) { this.entregavelPrevisto = entregavelPrevisto; }
    public String getEquipesNomes() { return equipesNomes; }
    public void setEquipesNomes(String equipesNomes) { this.equipesNomes = equipesNomes; }

    @Override
    public String toString() {
        return nome;
    }
}
