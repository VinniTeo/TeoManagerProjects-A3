package model;

public class Equipe {
    private int id;
    private String nome;
    private String descricao;
    private String projetosNomes;

    public Equipe() {}

    public Equipe(int id, String nome, String descricao, String projetosNomes) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.projetosNomes = projetosNomes;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getProjetosNomes() { return projetosNomes; }
    public void setProjetosNomes(String projetosNomes) { this.projetosNomes = projetosNomes; }

    @Override
    public String toString() {
        return nome;
    }
}
