package model;

import java.time.LocalDate;

public class Tarefa {
    private int id;
    private String titulo;
    private String descricao;
    private int projetoId;
    private String projetoNome;
    private int responsavelId;
    private String responsavelNome;
    private LocalDate prazo;
    private String status;
    private String observacoes;
    private String entregavel;

    public Tarefa() {}

    public Tarefa(int id, String titulo, String descricao, int projetoId, String projetoNome, int responsavelId, String responsavelNome, LocalDate prazo, String status, String observacoes, String entregavel) {
        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.projetoId = projetoId;
        this.projetoNome = projetoNome;
        this.responsavelId = responsavelId;
        this.responsavelNome = responsavelNome;
        this.prazo = prazo;
        this.status = status;
        this.observacoes = observacoes;
        this.entregavel = entregavel;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public int getProjetoId() { return projetoId; }
    public void setProjetoId(int projetoId) { this.projetoId = projetoId; }
    public String getProjetoNome() { return projetoNome; }
    public void setProjetoNome(String projetoNome) { this.projetoNome = projetoNome; }
    public int getResponsavelId() { return responsavelId; }
    public void setResponsavelId(int responsavelId) { this.responsavelId = responsavelId; }
    public String getResponsavelNome() { return responsavelNome; }
    public void setResponsavelNome(String responsavelNome) { this.responsavelNome = responsavelNome; }
    public LocalDate getPrazo() { return prazo; }
    public void setPrazo(LocalDate prazo) { this.prazo = prazo; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public String getEntregavel() { return entregavel; }
    public void setEntregavel(String entregavel) { this.entregavel = entregavel; }
}
