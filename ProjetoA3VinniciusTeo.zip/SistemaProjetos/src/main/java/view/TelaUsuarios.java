package view;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaUsuarios extends JPanel {
    private final TelaPrincipal principal;
    private final UsuarioDAO dao = new UsuarioDAO();
    private final JTable tabela = Theme.table();
    private final JTextField txtNome = Theme.textField();
    private final JTextField txtCpf = Theme.textField();
    private final JTextField txtEmail = Theme.textField();
    private final JTextField txtCargo = Theme.textField();
    private final JTextField txtLogin = Theme.textField();
    private final JPasswordField txtSenha = Theme.passwordField();
    private final JComboBox<String> cbPerfil = Theme.combo(new String[]{"Administrador", "Gerente", "Colaborador"});
    private int idSelecionado = 0;

    public TelaUsuarios(TelaPrincipal principal) {
        this.principal = principal;
        setLayout(new BorderLayout());
        add(montar(), BorderLayout.CENTER);
        carregarTabela();
    }

    private JPanel montar() {
        JPanel page = Theme.page("Usuários", "Cadastro, edição, listagem e permissões dos usuários do sistema.");
        JPanel body = new JPanel(new BorderLayout(18, 0));
        body.setOpaque(false);
        body.add(formulario(), BorderLayout.WEST);
        body.add(tabela(), BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private JPanel formulario() {
        JPanel form = Theme.card();
        form.setLayout(new GridLayout(0, 1, 0, 8));
        form.setPreferredSize(new Dimension(330, 0));
        form.add(Theme.label("Nome completo *"));
        form.add(txtNome);
        form.add(Theme.label("CPF *"));
        form.add(txtCpf);
        form.add(Theme.label("E-mail *"));
        form.add(txtEmail);
        form.add(Theme.label("Cargo"));
        form.add(txtCargo);
        form.add(Theme.label("Login *"));
        form.add(txtLogin);
        form.add(Theme.label("Senha *"));
        form.add(txtSenha);
        form.add(Theme.label("Perfil"));
        form.add(cbPerfil);
        JButton salvar = Theme.primaryButton("Salvar usuário");
        JButton limpar = Theme.secondaryButton("Limpar");
        JButton excluir = Theme.secondaryButton("Excluir");
        salvar.addActionListener(e -> salvar());
        limpar.addActionListener(e -> limpar());
        excluir.addActionListener(e -> excluir());
        form.add(salvar);
        form.add(limpar);
        form.add(excluir);
        return form;
    }

    private JScrollPane tabela() {
        tabela.setModel(new DefaultTableModel(new Object[]{"ID", "Nome", "CPF", "E-mail", "Cargo", "Login", "Perfil", "Ativo"}, 0));
        tabela.getSelectionModel().addListSelectionListener(e -> selecionarLinha());
        return new JScrollPane(tabela);
    }

    private void carregarTabela() {
        try {
            DefaultTableModel model = (DefaultTableModel) tabela.getModel();
            model.setRowCount(0);
            List<Usuario> lista = dao.listar();
            for (Usuario u : lista) {
                model.addRow(new Object[]{u.getId(), u.getNomeCompleto(), u.getCpf(), u.getEmail(), u.getCargo(), u.getLogin(), u.getPerfil(), u.isAtivo() ? "Sim" : "Não"});
            }
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void selecionarLinha() {
        int row = tabela.getSelectedRow();
        if (row < 0) return;
        idSelecionado = Integer.parseInt(tabela.getValueAt(row, 0).toString());
        txtNome.setText(String.valueOf(tabela.getValueAt(row, 1)));
        txtCpf.setText(String.valueOf(tabela.getValueAt(row, 2)));
        txtEmail.setText(String.valueOf(tabela.getValueAt(row, 3)));
        txtCargo.setText(String.valueOf(tabela.getValueAt(row, 4)));
        txtLogin.setText(String.valueOf(tabela.getValueAt(row, 5)));
        txtSenha.setText("");
        cbPerfil.setSelectedItem(String.valueOf(tabela.getValueAt(row, 6)));
    }

    private void salvar() {
        if (txtNome.getText().trim().isEmpty() || txtCpf.getText().trim().isEmpty() || txtEmail.getText().trim().isEmpty() || txtLogin.getText().trim().isEmpty()) {
            Theme.message(this, "Preencha os campos obrigatórios.");
            return;
        }
        try {
            Usuario u = new Usuario();
            u.setId(idSelecionado);
            u.setNomeCompleto(txtNome.getText().trim());
            u.setCpf(txtCpf.getText().trim());
            u.setEmail(txtEmail.getText().trim());
            u.setCargo(txtCargo.getText().trim());
            u.setLogin(txtLogin.getText().trim());
            String senha = new String(txtSenha.getPassword()).trim();
            u.setSenha(senha.isEmpty() ? "123456" : senha);
            u.setPerfil(cbPerfil.getSelectedItem().toString());
            u.setAtivo(true);
            if (idSelecionado == 0) dao.salvar(u); else dao.atualizar(u);
            Theme.message(this, "Usuário salvo com sucesso.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void excluir() {
        if (idSelecionado == 0) {
            Theme.message(this, "Selecione um usuário para excluir.");
            return;
        }
        int op = JOptionPane.showConfirmDialog(this, "Deseja desativar o usuário selecionado?", "Confirmação", JOptionPane.YES_NO_OPTION);
        if (op != JOptionPane.YES_OPTION) return;
        try {
            dao.excluir(idSelecionado);
            Theme.message(this, "Usuário desativado.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void limpar() {
        idSelecionado = 0;
        txtNome.setText("");
        txtCpf.setText("");
        txtEmail.setText("");
        txtCargo.setText("");
        txtLogin.setText("");
        txtSenha.setText("");
        cbPerfil.setSelectedIndex(0);
        tabela.clearSelection();
    }
}
