package view;

import model.Usuario;

public class AppContext {
    private static Usuario usuarioLogado;

    public static Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public static void setUsuarioLogado(Usuario usuarioLogado) {
        AppContext.usuarioLogado = usuarioLogado;
    }
}
