package view;

public class ComboItem {
    private final int id;
    private final String nome;

    public ComboItem(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return nome;
    }
}
