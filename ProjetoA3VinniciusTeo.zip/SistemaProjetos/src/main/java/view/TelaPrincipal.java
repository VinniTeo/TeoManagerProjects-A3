package view;

import dao.EquipeDAO;
import dao.ProjetoDAO;
import dao.TarefaDAO;
import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class TelaPrincipal extends JFrame {
    private final JPanel conteudo = new JPanel(new BorderLayout());
    private final Usuario usuario = AppContext.getUsuarioLogado();

    public TelaPrincipal() {
        setTitle("TeoManagerProjects - Sistema de Gerenciamento de Projetos e Equipes");
        setSize(1180, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(980, 640));
        montarTela();
        mostrarDashboard();
    }

    private void montarTela() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG);
        root.add(menuLateral(), BorderLayout.WEST);
        conteudo.setBackground(Theme.BG);
        root.add(conteudo, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel menuLateral() {
        JPanel menu = new JPanel(new BorderLayout());
        menu.setPreferredSize(new Dimension(250, 0));
        menu.setBackground(Theme.PRIMARY);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(Theme.PRIMARY);
        topo.setBorder(new EmptyBorder(24, 20, 18, 20));
        JLabel titulo = new JLabel("TeoManagerProjects");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 21));
        titulo.setForeground(Color.WHITE);
        JLabel subtitulo = new JLabel(usuario.getNomeCompleto() + " - " + usuario.getPerfil());
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitulo.setForeground(new Color(210, 220, 235));
        topo.add(titulo, BorderLayout.NORTH);
        topo.add(subtitulo, BorderLayout.SOUTH);

        JPanel botoes = new JPanel(new GridLayout(0, 1, 0, 8));
        botoes.setBackground(Theme.PRIMARY);
        botoes.setBorder(new EmptyBorder(10, 14, 10, 14));

        adicionarBotao(botoes, "Dashboard", this::mostrarDashboard);
        if (ehAdministrador()) adicionarBotao(botoes, "Usuários", () -> trocarConteudo(new TelaUsuarios(this)));
        if (ehAdministrador() || ehGerente()) adicionarBotao(botoes, "Projetos", () -> trocarConteudo(new TelaProjetos(this)));
        if (ehAdministrador() || ehGerente()) adicionarBotao(botoes, "Equipes", () -> trocarConteudo(new TelaEquipes(this)));
        adicionarBotao(botoes, "Tarefas", () -> trocarConteudo(new TelaTarefas(this)));
        adicionarBotao(botoes, "Relatórios", () -> trocarConteudo(new TelaRelatorios(this)));

        JPanel rodape = new JPanel(new BorderLayout());
        rodape.setBackground(Theme.PRIMARY);
        rodape.setBorder(new EmptyBorder(16, 14, 16, 14));
        JButton sair = Theme.menuButton("Sair");
        sair.addActionListener(e -> sair());
        rodape.add(sair, BorderLayout.CENTER);

        menu.add(topo, BorderLayout.NORTH);
        menu.add(botoes, BorderLayout.CENTER);
        menu.add(rodape, BorderLayout.SOUTH);
        return menu;
    }

    private void adicionarBotao(JPanel p, String texto, Runnable acao) {
        JButton b = Theme.menuButton(texto);
        b.addActionListener(e -> acao.run());
        p.add(b);
    }

    public void trocarConteudo(JPanel painel) {
        conteudo.removeAll();
        conteudo.add(painel, BorderLayout.CENTER);
        conteudo.revalidate();
        conteudo.repaint();
    }

    public void mostrarDashboard() {
        JPanel page = Theme.page("Dashboard", "Visão geral simples do TeoManagerProjects.");
        JPanel center = new JPanel(new BorderLayout(0, 18));
        center.setOpaque(false);

        int totalUsuarios = 0;
        int totalProjetos = 0;
        int totalEquipes = 0;
        int totalTarefas = 0;

        try {
            totalUsuarios = new UsuarioDAO().contar();
            totalProjetos = new ProjetoDAO().contar();
            totalEquipes = new EquipeDAO().contar();
            totalTarefas = new TarefaDAO().contar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Não foi possível carregar os números do dashboard.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }

        JPanel cards = new JPanel(new GridLayout(1, 4, 18, 0));
        cards.setOpaque(false);
        cards.add(cardNumero("Usuários", totalUsuarios, "cadastrados"));
        cards.add(cardNumero("Projetos", totalProjetos, "cadastrados"));
        cards.add(cardNumero("Equipes", totalEquipes, "cadastradas"));
        cards.add(cardNumero("Tarefas", totalTarefas, "registradas"));
        center.add(cards, BorderLayout.NORTH);

        JPanel areaPrincipal = new JPanel(new GridLayout(1, 2, 18, 0));
        areaPrincipal.setOpaque(false);

        JPanel resumo = Theme.card();
        resumo.setLayout(new BorderLayout(0, 12));
        JLabel tituloResumo = new JLabel("Resumo do sistema");
        tituloResumo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        tituloResumo.setForeground(Theme.TEXT);

        JTextArea texto = new JTextArea();
        texto.setEditable(false);
        texto.setOpaque(false);
        texto.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        texto.setForeground(Theme.TEXT);
        texto.setText("A tela mostra os principais cadastros do sistema.\n\n" +
                "• Usuários cadastrados no ambiente.\n" +
                "• Projetos em controle pela plataforma.\n" +
                "• Equipes vinculadas aos projetos.\n" +
                "• Tarefas registradas para acompanhamento.\n\n" +
                "Use o menu lateral para acessar cada módulo.");
        resumo.add(tituloResumo, BorderLayout.NORTH);
        resumo.add(texto, BorderLayout.CENTER);

        JPanel graficoCard = Theme.card();
        graficoCard.setLayout(new BorderLayout(0, 12));
        JLabel tituloGrafico = new JLabel("Gráfico de cadastros");
        tituloGrafico.setFont(new Font("Segoe UI", Font.BOLD, 18));
        tituloGrafico.setForeground(Theme.TEXT);
        graficoCard.add(tituloGrafico, BorderLayout.NORTH);
        graficoCard.add(new GraficoResumoPanel(totalUsuarios, totalProjetos, totalEquipes, totalTarefas), BorderLayout.CENTER);

        areaPrincipal.add(resumo);
        areaPrincipal.add(graficoCard);
        center.add(areaPrincipal, BorderLayout.CENTER);

        page.add(center, BorderLayout.CENTER);
        trocarConteudo(page);
    }

    private JPanel cardNumero(String titulo, int valor, String detalhe) {
        JPanel c = Theme.card();
        c.setLayout(new GridLayout(3, 1));
        JLabel t = new JLabel(titulo);
        t.setFont(new Font("Segoe UI", Font.BOLD, 15));
        t.setForeground(Theme.PRIMARY);
        JLabel v = new JLabel(String.valueOf(valor));
        v.setFont(new Font("Segoe UI", Font.BOLD, 32));
        v.setForeground(Theme.TEXT);
        JLabel d = new JLabel(detalhe);
        d.setFont(Theme.NORMAL);
        d.setForeground(Theme.MUTED);
        c.add(t);
        c.add(v);
        c.add(d);
        return c;
    }

    private static class GraficoResumoPanel extends JPanel {
        private final String[] nomes = {"Usuários", "Projetos", "Equipes", "Tarefas"};
        private final int[] valores;

        GraficoResumoPanel(int usuarios, int projetos, int equipes, int tarefas) {
            this.valores = new int[]{usuarios, projetos, equipes, tarefas};
            setOpaque(false);
            setPreferredSize(new Dimension(420, 260));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int largura = getWidth();
            int altura = getHeight();
            int margemEsquerda = 52;
            int margemDireita = 24;
            int margemTopo = 24;
            int margemBaixo = 54;
            int baseY = altura - margemBaixo;
            int areaAltura = Math.max(1, baseY - margemTopo);
            int areaLargura = Math.max(1, largura - margemEsquerda - margemDireita);

            int maior = 1;
            for (int valor : valores) {
                if (valor > maior) maior = valor;
            }

            g2.setColor(new Color(226, 232, 240));
            g2.drawLine(margemEsquerda, baseY, largura - margemDireita, baseY);
            g2.drawLine(margemEsquerda, margemTopo, margemEsquerda, baseY);

            int espacamento = 22;
            int quantidade = valores.length;
            int larguraBarra = Math.max(36, (areaLargura - (espacamento * (quantidade + 1))) / quantidade);

            for (int i = 0; i < quantidade; i++) {
                int valor = valores[i];
                int alturaBarra = (int) ((valor / (double) maior) * (areaAltura - 20));
                int x = margemEsquerda + espacamento + i * (larguraBarra + espacamento);
                int y = baseY - alturaBarra;

                g2.setColor(new Color(135, 40, 150));
                g2.fillRoundRect(x, y, larguraBarra, alturaBarra, 14, 14);

                g2.setColor(Theme.TEXT);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 15));
                String valorTexto = String.valueOf(valor);
                int valorX = x + (larguraBarra - g2.getFontMetrics().stringWidth(valorTexto)) / 2;
                g2.drawString(valorTexto, valorX, Math.max(margemTopo + 14, y - 8));

                g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                g2.setColor(Theme.MUTED);
                String nome = nomes[i];
                int nomeX = x + (larguraBarra - g2.getFontMetrics().stringWidth(nome)) / 2;
                g2.drawString(nome, nomeX, baseY + 24);
            }

            g2.dispose();
        }
    }

    private boolean ehAdministrador() {
        return usuario != null && "Administrador".equalsIgnoreCase(usuario.getPerfil());
    }

    private boolean ehGerente() {
        return usuario != null && "Gerente".equalsIgnoreCase(usuario.getPerfil());
    }

    private void sair() {
        int op = JOptionPane.showConfirmDialog(this, "Deseja sair do sistema?", "Confirmação", JOptionPane.YES_NO_OPTION);
        if (op == JOptionPane.YES_OPTION) {
            AppContext.setUsuarioLogado(null);
            new TelaLogin().setVisible(true);
            dispose();
        }
    }
}
