package view;

import dao.EquipeDAO;
import model.Equipe;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TelaEquipes extends JPanel {
    private final TelaPrincipal principal;
    private final EquipeDAO dao = new EquipeDAO();
    private final JTable tabela = Theme.table();
    private final JTextField txtNome = Theme.textField();
    private final JTextArea txtDescricao = Theme.textArea(5);
    private int idSelecionado = 0;

    public TelaEquipes(TelaPrincipal principal) {
        this.principal = principal;
        setLayout(new BorderLayout());
        add(montar(), BorderLayout.CENTER);
        carregarTabela();
    }

    private JPanel montar() {
        JPanel page = Theme.page("Equipes", "Cadastro de equipes. O vínculo com projetos é feito na tela Projetos.");
        JPanel body = new JPanel(new BorderLayout(18, 0));
        body.setOpaque(false);

        JScrollPane formScroll = new JScrollPane(formulario());
        formScroll.setBorder(null);
        formScroll.getVerticalScrollBar().setUnitIncrement(16);
        formScroll.setPreferredSize(new Dimension(400, 0));

        body.add(formScroll, BorderLayout.WEST);
        body.add(tabela(), BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private JPanel formulario() {
        JPanel form = Theme.card();
        form.setLayout(new GridBagLayout());
        form.setPreferredSize(new Dimension(370, 430));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets = new Insets(0, 0, 8, 0);
        int linha = 0;

        linha = adicionarCampo(form, gbc, linha, "Nome da equipe *", txtNome);
        JScrollPane descricaoScroll = new JScrollPane(txtDescricao);
        descricaoScroll.setPreferredSize(new Dimension(330, 120));
        linha = adicionarCampo(form, gbc, linha, "Descrição", descricaoScroll);

        JLabel aviso = new JLabel("Associe esta equipe a um ou mais projetos na tela Projetos.");
        aviso.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        aviso.setForeground(Theme.MUTED);
        gbc.gridy = linha++;
        form.add(aviso, gbc);

        JButton salvar = Theme.primaryButton("Salvar equipe");
        JButton limpar = Theme.secondaryButton("Limpar");
        JButton excluir = Theme.secondaryButton("Excluir");
        salvar.addActionListener(e -> salvar());
        limpar.addActionListener(e -> limpar());
        excluir.addActionListener(e -> excluir());
        gbc.gridy = linha++;
        form.add(salvar, gbc);
        gbc.gridy = linha++;
        form.add(limpar, gbc);
        gbc.gridy = linha++;
        form.add(excluir, gbc);
        return form;
    }

    private int adicionarCampo(JPanel form, GridBagConstraints gbc, int linha, String rotulo, Component campo) {
        gbc.gridy = linha++;
        form.add(Theme.label(rotulo), gbc);
        gbc.gridy = linha++;
        form.add(campo, gbc);
        return linha;
    }

    private JScrollPane tabela() {
        tabela.setModel(new DefaultTableModel(new Object[]{"ID", "Equipe", "Projetos vinculados", "Descrição"}, 0));
        tabela.getSelectionModel().addListSelectionListener(e -> selecionarLinha());
        return new JScrollPane(tabela);
    }

    private void carregarTabela() {
        try {
            DefaultTableModel model = (DefaultTableModel) tabela.getModel();
            model.setRowCount(0);
            for (Equipe e : dao.listar()) model.addRow(new Object[]{e.getId(), e.getNome(), e.getProjetosNomes(), e.getDescricao()});
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void selecionarLinha() {
        int row = tabela.getSelectedRow();
        if (row < 0) return;
        try {
            Equipe e = dao.listar().get(row);
            idSelecionado = e.getId();
            txtNome.setText(e.getNome());
            txtDescricao.setText(e.getDescricao());
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void salvar() {
        if (txtNome.getText().trim().isEmpty()) {
            Theme.message(this, "Informe o nome da equipe.");
            return;
        }
        try {
            Equipe e = new Equipe();
            e.setId(idSelecionado);
            e.setNome(txtNome.getText().trim());
            e.setDescricao(txtDescricao.getText().trim());
            if (idSelecionado == 0) dao.salvar(e); else dao.atualizar(e);
            Theme.message(this, "Equipe salva com sucesso.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void excluir() {
        if (idSelecionado == 0) {
            Theme.message(this, "Selecione uma equipe para excluir.");
            return;
        }
        int op = JOptionPane.showConfirmDialog(this, "Deseja excluir esta equipe?", "Confirmação", JOptionPane.YES_NO_OPTION);
        if (op != JOptionPane.YES_OPTION) return;
        try {
            dao.excluir(idSelecionado);
            Theme.message(this, "Equipe excluída.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void limpar() {
        idSelecionado = 0;
        txtNome.setText("");
        txtDescricao.setText("");
        tabela.clearSelection();
    }
}
