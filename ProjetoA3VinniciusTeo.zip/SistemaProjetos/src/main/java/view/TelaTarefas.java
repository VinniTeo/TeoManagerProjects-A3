package view;

import dao.ProjetoDAO;
import dao.TarefaDAO;
import dao.UsuarioDAO;
import model.Projeto;
import model.Tarefa;
import model.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class TelaTarefas extends JPanel {
    private final TelaPrincipal principal;
    private final TarefaDAO dao = new TarefaDAO();
    private final JTable tabela = Theme.table();
    private final JTextField txtTitulo = Theme.textField();
    private final JTextField txtPrazo = Theme.textField();
    private final JTextField txtEntregavel = Theme.textField();
    private final JTextArea txtDescricao = Theme.textArea(3);
    private final JTextArea txtObservacoes = Theme.textArea(4);
    private final JComboBox<ComboItem> cbProjeto = new JComboBox<>();
    private final JComboBox<ComboItem> cbResponsavel = new JComboBox<>();
    private final JComboBox<String> cbStatus = Theme.combo(new String[]{"Pendente", "Em andamento", "Concluída", "Atrasada", "Cancelada"});
    private final Usuario usuario = AppContext.getUsuarioLogado();
    private int idSelecionado = 0;

    public TelaTarefas(TelaPrincipal principal) {
        this.principal = principal;
        setLayout(new BorderLayout());
        add(montar(), BorderLayout.CENTER);
        carregarCombos();
        aplicarPermissao();
        carregarTabela();
    }

    private JPanel montar() {
        JPanel page = Theme.page("Tarefas", "Controle de tarefas, responsáveis, prazos, entregáveis, status e observações.");
        JPanel body = new JPanel(new BorderLayout(18, 0));
        body.setOpaque(false);
        body.add(formulario(), BorderLayout.WEST);
        body.add(tabela(), BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private JPanel formulario() {
        JPanel form = Theme.card();
        form.setLayout(new GridLayout(0, 1, 0, 7));
        form.setPreferredSize(new Dimension(360, 0));
        form.add(Theme.label("Título *"));
        form.add(txtTitulo);
        form.add(Theme.label("Descrição"));
        form.add(new JScrollPane(txtDescricao));
        form.add(Theme.label("Projeto"));
        form.add(cbProjeto);
        form.add(Theme.label("Responsável"));
        form.add(cbResponsavel);
        form.add(Theme.label("Prazo (AAAA-MM-DD)"));
        form.add(txtPrazo);
        form.add(Theme.label("Status"));
        form.add(cbStatus);
        form.add(Theme.label("Entregável"));
        form.add(txtEntregavel);
        form.add(Theme.label("Observações"));
        form.add(new JScrollPane(txtObservacoes));
        JButton salvar = Theme.primaryButton("Salvar tarefa");
        JButton limpar = Theme.secondaryButton("Limpar");
        JButton excluir = Theme.secondaryButton("Excluir");
        salvar.addActionListener(e -> salvar());
        limpar.addActionListener(e -> limpar());
        excluir.addActionListener(e -> excluir());
        form.add(salvar);
        form.add(limpar);
        form.add(excluir);
        if (ehColaborador()) excluir.setEnabled(false);
        return form;
    }

    private JScrollPane tabela() {
        tabela.setModel(new DefaultTableModel(new Object[]{"ID", "Título", "Projeto", "Responsável", "Prazo", "Status", "Entregável", "Observações"}, 0));
        tabela.getSelectionModel().addListSelectionListener(e -> selecionarLinha());
        return new JScrollPane(tabela);
    }

    private void carregarCombos() {
        try {
            cbProjeto.removeAllItems();
            for (Projeto p : new ProjetoDAO().listar()) cbProjeto.addItem(new ComboItem(p.getId(), p.getNome()));
            cbResponsavel.removeAllItems();
            for (Usuario u : new UsuarioDAO().listarAtivos()) cbResponsavel.addItem(new ComboItem(u.getId(), u.getNomeCompleto()));
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void aplicarPermissao() {
        if (!ehColaborador()) return;
        txtTitulo.setEnabled(false);
        txtDescricao.setEnabled(false);
        cbProjeto.setEnabled(false);
        cbResponsavel.setEnabled(false);
        txtPrazo.setEnabled(false);
        txtEntregavel.setEnabled(false);
    }

    private boolean ehColaborador() {
        return usuario != null && "Colaborador".equalsIgnoreCase(usuario.getPerfil());
    }

    private void carregarTabela() {
        try {
            DefaultTableModel model = (DefaultTableModel) tabela.getModel();
            model.setRowCount(0);
            List<Tarefa> lista = ehColaborador() ? dao.listarDoResponsavel(usuario.getId()) : dao.listar();
            for (Tarefa t : lista) {
                model.addRow(new Object[]{t.getId(), t.getTitulo(), t.getProjetoNome(), t.getResponsavelNome(), t.getPrazo(), t.getStatus(), t.getEntregavel(), t.getObservacoes()});
            }
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void selecionarLinha() {
        int row = tabela.getSelectedRow();
        if (row < 0) return;
        try {
            List<Tarefa> lista = ehColaborador() ? dao.listarDoResponsavel(usuario.getId()) : dao.listar();
            Tarefa t = lista.get(row);
            idSelecionado = t.getId();
            txtTitulo.setText(t.getTitulo());
            txtDescricao.setText(t.getDescricao());
            txtPrazo.setText(t.getPrazo() == null ? "" : String.valueOf(t.getPrazo()));
            txtEntregavel.setText(t.getEntregavel());
            txtObservacoes.setText(t.getObservacoes());
            cbStatus.setSelectedItem(t.getStatus());
            selecionarCombo(cbProjeto, t.getProjetoId());
            selecionarCombo(cbResponsavel, t.getResponsavelId());
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void selecionarCombo(JComboBox<ComboItem> combo, int id) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).getId() == id) combo.setSelectedIndex(i);
        }
    }

    private void salvar() {
        if (ehColaborador()) {
            atualizarComoColaborador();
            return;
        }
        if (txtTitulo.getText().trim().isEmpty() || cbProjeto.getSelectedItem() == null || cbResponsavel.getSelectedItem() == null) {
            Theme.message(this, "Informe título, projeto e responsável.");
            return;
        }
        try {
            Tarefa t = new Tarefa();
            t.setId(idSelecionado);
            t.setTitulo(txtTitulo.getText().trim());
            t.setDescricao(txtDescricao.getText().trim());
            t.setProjetoId(((ComboItem) cbProjeto.getSelectedItem()).getId());
            t.setResponsavelId(((ComboItem) cbResponsavel.getSelectedItem()).getId());
            t.setPrazo(txtPrazo.getText().trim().isEmpty() ? null : LocalDate.parse(txtPrazo.getText().trim()));
            t.setStatus(cbStatus.getSelectedItem().toString());
            t.setEntregavel(txtEntregavel.getText().trim());
            t.setObservacoes(txtObservacoes.getText().trim());
            if (idSelecionado == 0) dao.salvar(t); else dao.atualizar(t);
            Theme.message(this, "Tarefa salva com sucesso.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void atualizarComoColaborador() {
        if (idSelecionado == 0) {
            Theme.message(this, "Selecione uma tarefa para atualizar.");
            return;
        }
        try {
            dao.atualizarStatusObservacao(idSelecionado, cbStatus.getSelectedItem().toString(), txtObservacoes.getText().trim());
            Theme.message(this, "Status e observações atualizados.");
            carregarTabela();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void excluir() {
        if (idSelecionado == 0) {
            Theme.message(this, "Selecione uma tarefa para excluir.");
            return;
        }
        int op = JOptionPane.showConfirmDialog(this, "Deseja excluir esta tarefa?", "Confirmação", JOptionPane.YES_NO_OPTION);
        if (op != JOptionPane.YES_OPTION) return;
        try {
            dao.excluir(idSelecionado);
            Theme.message(this, "Tarefa excluída.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void limpar() {
        idSelecionado = 0;
        txtTitulo.setText("");
        txtDescricao.setText("");
        txtPrazo.setText("");
        txtEntregavel.setText("");
        txtObservacoes.setText("");
        cbStatus.setSelectedIndex(0);
        if (cbProjeto.getItemCount() > 0) cbProjeto.setSelectedIndex(0);
        if (cbResponsavel.getItemCount() > 0) cbResponsavel.setSelectedIndex(0);
        tabela.clearSelection();
    }
}
