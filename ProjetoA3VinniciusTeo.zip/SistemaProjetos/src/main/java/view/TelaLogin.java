package view;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class TelaLogin extends JFrame {
    private final JTextField txtLogin = Theme.textField();
    private final JPasswordField txtSenha = Theme.passwordField();

    public TelaLogin() {
        setTitle("TeoManagerProjects - Login");
        setSize(920, 560);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        montarTela();
    }

    private void montarTela() {
        JPanel root = new JPanel(new GridLayout(1, 2));
        root.setBackground(Theme.BG);

        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(Theme.PRIMARY);
        left.setBorder(new EmptyBorder(40, 44, 40, 44));

        JLabel logoSistema = new JLabel("TeoManagerProjects");
        logoSistema.setForeground(Color.WHITE);
        logoSistema.setFont(new Font("Segoe UI", Font.BOLD, 30));

        JTextArea texto = new JTextArea("Sistema de Gerenciamento de Projetos e Equipes\n\nÂnima Educação");
        texto.setEditable(false);
        texto.setOpaque(false);
        texto.setForeground(new Color(222, 232, 244));
        texto.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        texto.setLineWrap(true);
        texto.setWrapStyleWord(true);

        JLabel logoAnima = new JLabel(Theme.logo(220, 85));
        logoAnima.setHorizontalAlignment(SwingConstants.LEFT);
        JLabel assinatura = new JLabel("Projeto A3 - Vinicius Teo");
        assinatura.setForeground(new Color(210, 220, 235));
        assinatura.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JPanel bottom = new JPanel(new GridLayout(2, 1));
        bottom.setOpaque(false);
        bottom.add(logoAnima);
        bottom.add(assinatura);

        left.add(logoSistema, BorderLayout.NORTH);
        left.add(texto, BorderLayout.CENTER);
        left.add(bottom, BorderLayout.SOUTH);

        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Theme.BG);
        JPanel card = Theme.card();
        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(360, 360));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        JLabel title = new JLabel("Entrar no sistema");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(Theme.TEXT);
        card.add(title, c);

        c.gridy++;
        JLabel subtitulo = new JLabel("Informe suas credenciais de acesso.");
        subtitulo.setFont(Theme.NORMAL);
        subtitulo.setForeground(Theme.MUTED);
        card.add(subtitulo, c);

        c.gridy++;
        c.gridwidth = 2;
        card.add(Theme.label("Login"), c);
        c.gridy++;
        card.add(txtLogin, c);
        c.gridy++;
        card.add(Theme.label("Senha"), c);
        c.gridy++;
        card.add(txtSenha, c);

        JButton btnEntrar = Theme.primaryButton("Entrar");
        JButton btnSair = Theme.secondaryButton("Sair");
        btnEntrar.addActionListener(e -> autenticar());
        btnSair.addActionListener(e -> System.exit(0));
        txtSenha.addActionListener(e -> autenticar());

        c.gridy++;
        c.gridwidth = 1;
        c.weightx = 1;
        card.add(btnEntrar, c);
        c.gridx = 1;
        card.add(btnSair, c);

        right.add(card);
        root.add(left);
        root.add(right);
        setContentPane(root);
    }

    private void autenticar() {
        String login = txtLogin.getText().trim();
        String senha = new String(txtSenha.getPassword()).trim();
        if (login.isEmpty() || senha.isEmpty()) {
            Theme.message(this, "Informe login e senha.");
            return;
        }
        try {
            Usuario usuario = new UsuarioDAO().autenticar(login, senha);
            if (usuario == null) {
                Theme.message(this, "Login ou senha inválidos.");
                return;
            }
            AppContext.setUsuarioLogado(usuario);
            new TelaPrincipal().setVisible(true);
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Não foi possível conectar ao banco de dados.\n" + ex.getMessage(), "Erro de conexão", JOptionPane.ERROR_MESSAGE);
        }
    }
}
