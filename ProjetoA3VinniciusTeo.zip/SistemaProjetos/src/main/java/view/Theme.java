package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.net.URL;

public class Theme {
    public static final Color PRIMARY = new Color(27, 50, 78);
    public static final Color PRIMARY_DARK = new Color(18, 35, 56);
    public static final Color ACCENT = new Color(135, 40, 150);
    public static final Color ACCENT_LIGHT = new Color(231, 219, 238);
    public static final Color BG = new Color(245, 247, 251);
    public static final Color CARD = Color.WHITE;
    public static final Color TEXT = new Color(42, 48, 58);
    public static final Color MUTED = new Color(95, 107, 122);
    public static final Font TITLE = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font SUBTITLE = new Font("Segoe UI", Font.PLAIN, 16);
    public static final Font LABEL = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font NORMAL = new Font("Segoe UI", Font.PLAIN, 13);

    public static JPanel page(String title, String subtitle) {
        JPanel page = new JPanel(new BorderLayout(0, 18));
        page.setBackground(BG);
        page.setBorder(new EmptyBorder(24, 28, 24, 28));
        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setOpaque(false);
        JLabel h1 = new JLabel(title);
        h1.setFont(TITLE);
        h1.setForeground(TEXT);
        JLabel h2 = new JLabel(subtitle);
        h2.setFont(SUBTITLE);
        h2.setForeground(MUTED);
        header.add(h1);
        header.add(h2);
        page.add(header, BorderLayout.NORTH);
        return page;
    }

    public static JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(CARD);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 234)),
                new EmptyBorder(16, 18, 16, 18)
        ));
        return p;
    }

    private static void aplicarEstiloBotao(JButton b, Color fundo, Color texto, boolean alinharEsquerda) {
        b.setFocusPainted(false);
        b.setUI(new javax.swing.plaf.basic.BasicButtonUI());
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(false);
        b.setBackground(fundo);
        b.setForeground(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(12, 18, 12, 18));
        if (alinharEsquerda) {
            b.setHorizontalAlignment(SwingConstants.LEFT);
        } else {
            b.setHorizontalAlignment(SwingConstants.CENTER);
        }
    }

    public static JButton menuButton(String text) {
        JButton b = new JButton(text);
        aplicarEstiloBotao(b, PRIMARY_DARK, Color.WHITE, true);
        return b;
    }

    public static JButton primaryButton(String text) {
        JButton b = new JButton(text);
        aplicarEstiloBotao(b, ACCENT, Color.WHITE, false);
        return b;
    }

    public static JButton secondaryButton(String text) {
        JButton b = new JButton(text);
        aplicarEstiloBotao(b, new Color(213, 226, 241), PRIMARY_DARK, false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(154, 172, 196)),
                new EmptyBorder(10, 16, 10, 16)
        ));
        return b;
    }

    public static JTextField textField() {
        JTextField f = new JTextField();
        f.setFont(NORMAL);
        f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(210, 216, 226)), new EmptyBorder(8, 10, 8, 10)));
        return f;
    }

    public static JPasswordField passwordField() {
        JPasswordField f = new JPasswordField();
        f.setFont(NORMAL);
        f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(210, 216, 226)), new EmptyBorder(8, 10, 8, 10)));
        return f;
    }

    public static JTextArea textArea(int rows) {
        JTextArea a = new JTextArea(rows, 20);
        a.setLineWrap(true);
        a.setWrapStyleWord(true);
        a.setFont(NORMAL);
        a.setBorder(new EmptyBorder(8, 10, 8, 10));
        return a;
    }

    public static JComboBox<String> combo(String[] values) {
        JComboBox<String> combo = new JComboBox<>(values);
        combo.setFont(NORMAL);
        combo.setBackground(Color.WHITE);
        return combo;
    }

    public static JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(LABEL);
        l.setForeground(TEXT);
        return l;
    }

    public static JTable table() {
        JTable t = new JTable();
        t.setFont(NORMAL);
        t.setRowHeight(28);
        t.getTableHeader().setFont(LABEL);
        t.getTableHeader().setBackground(new Color(235, 240, 247));
        t.setSelectionBackground(ACCENT_LIGHT);
        t.setGridColor(new Color(229, 232, 238));
        return t;
    }

    public static ImageIcon logo(int width, int height) {
        URL url = Theme.class.getResource("/anima_logo.png");
        if (url == null) return null;
        ImageIcon icon = new ImageIcon(url);
        Image scaled = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }

    public static void message(Component parent, String text) {
        JOptionPane.showMessageDialog(parent, text, "TeoManagerProjects", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Component parent, Exception ex) {
        JOptionPane.showMessageDialog(parent, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
    }
}
