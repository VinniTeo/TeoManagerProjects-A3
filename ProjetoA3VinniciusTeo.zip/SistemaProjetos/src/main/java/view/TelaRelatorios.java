package view;

import dao.ProjetoDAO;
import dao.RelatorioDAO;
import dao.TarefaDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaRelatorios extends JPanel {
    private final RelatorioDAO dao = new RelatorioDAO();
    private final JTable tblStatus = Theme.table();
    private final JTable tblProjetos = Theme.table();
    private final JTable tblColaborador = Theme.table();
    private final JTable tblPrazos = Theme.table();

    public TelaRelatorios(TelaPrincipal principal) {
        setLayout(new BorderLayout());
        add(montar(), BorderLayout.CENTER);
        carregarRelatorios();
    }

    private JPanel montar() {
        JPanel page = Theme.page("Relatórios", "Indicadores de projetos, tarefas, colaboradores, prazos e entregáveis.");
        JPanel content = new JPanel(new BorderLayout(0, 18));
        content.setOpaque(false);
        content.add(cards(), BorderLayout.NORTH);
        content.add(tabs(), BorderLayout.CENTER);
        page.add(content, BorderLayout.CENTER);
        return page;
    }

    private JPanel cards() {
        JPanel p = new JPanel(new GridLayout(1, 4, 18, 0));
        p.setOpaque(false);
        try {
            ProjetoDAO pdao = new ProjetoDAO();
            TarefaDAO tdao = new TarefaDAO();
            p.add(card("Projetos", pdao.contar(), "total cadastrado"));
            p.add(card("Em andamento", pdao.contarPorStatus("Em andamento"), "projetos ativos"));
            p.add(card("Tarefas concluídas", tdao.contarPorStatus("Concluída"), "entregas finalizadas"));
            p.add(card("Tarefas atrasadas", tdao.contarPorStatus("Atrasada"), "atenção necessária"));
        } catch (Exception ex) {
            p.add(card("Projetos", 0, "sem conexão"));
            p.add(card("Em andamento", 0, "sem conexão"));
            p.add(card("Tarefas concluídas", 0, "sem conexão"));
            p.add(card("Tarefas atrasadas", 0, "sem conexão"));
        }
        return p;
    }

    private JPanel card(String titulo, int valor, String detalhe) {
        JPanel c = Theme.card();
        c.setLayout(new GridLayout(3, 1));
        JLabel t = new JLabel(titulo);
        t.setFont(new Font("Segoe UI", Font.BOLD, 14));
        t.setForeground(Theme.PRIMARY);
        JLabel v = new JLabel(String.valueOf(valor));
        v.setFont(new Font("Segoe UI", Font.BOLD, 28));
        v.setForeground(Theme.ACCENT);
        JLabel d = new JLabel(detalhe);
        d.setFont(Theme.NORMAL);
        d.setForeground(Theme.MUTED);
        c.add(t);
        c.add(v);
        c.add(d);
        return c;
    }

    private JTabbedPane tabs() {
        tblStatus.setModel(new DefaultTableModel(new Object[]{"Status", "Quantidade"}, 0));
        tblProjetos.setModel(new DefaultTableModel(new Object[]{"Projeto", "Equipes", "Status", "Tarefas", "Concluídas", "Atrasadas"}, 0));
        tblColaborador.setModel(new DefaultTableModel(new Object[]{"Colaborador", "Tarefas", "Concluídas"}, 0));
        tblPrazos.setModel(new DefaultTableModel(new Object[]{"Tarefa", "Projeto", "Equipes", "Responsável", "Prazo", "Status", "Entregável"}, 0));
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(Theme.NORMAL);
        tabs.addTab("Tarefas por status", new JScrollPane(tblStatus));
        tabs.addTab("Desempenho por projeto", new JScrollPane(tblProjetos));
        tabs.addTab("Tarefas por colaborador", new JScrollPane(tblColaborador));
        tabs.addTab("Prazos e entregáveis", new JScrollPane(tblPrazos));
        return tabs;
    }

    private void carregarRelatorios() {
        try {
            preencher(tblStatus, dao.tarefasPorStatus());
            preencher(tblProjetos, dao.desempenhoProjetos());
            preencher(tblColaborador, dao.tarefasPorColaborador());
            preencher(tblPrazos, dao.prazosEntregaveis());
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void preencher(JTable table, List<Object[]> linhas) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        for (Object[] row : linhas) model.addRow(row);
    }
}
