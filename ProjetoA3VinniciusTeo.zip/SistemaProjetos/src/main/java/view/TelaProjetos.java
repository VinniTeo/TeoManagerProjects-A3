package view;

import dao.EquipeDAO;
import dao.ProjetoDAO;
import dao.UsuarioDAO;
import model.Equipe;
import model.Projeto;
import model.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TelaProjetos extends JPanel {
    private final TelaPrincipal principal;
    private final ProjetoDAO dao = new ProjetoDAO();
    private final JTable tabela = Theme.table();
    private final JTextField txtNome = Theme.textField();
    private final JTextField txtInicio = Theme.textField();
    private final JTextField txtTermino = Theme.textField();
    private final JTextField txtEntregavel = Theme.textField();
    private final JTextArea txtDescricao = Theme.textArea(4);
    private final JComboBox<String> cbStatus = Theme.combo(new String[]{"Planejado", "Em andamento", "Concluído", "Cancelado", "Atrasado"});
    private final JComboBox<ComboItem> cbGerente = new JComboBox<>();
    private final DefaultListModel<ComboItem> equipesModel = new DefaultListModel<>();
    private final JList<ComboItem> listaEquipes = new JList<>(equipesModel);
    private int idSelecionado = 0;

    public TelaProjetos(TelaPrincipal principal) {
        this.principal = principal;
        setLayout(new BorderLayout());
        add(montar(), BorderLayout.CENTER);
        carregarGerentes();
        carregarEquipes();
        carregarTabela();
    }

    private JPanel montar() {
        JPanel page = Theme.page("Projetos", "Controle de projetos, responsáveis, equipes participantes, prazos, status e entregáveis.");
        JPanel body = new JPanel(new BorderLayout(18, 0));
        body.setOpaque(false);

        JScrollPane formScroll = new JScrollPane(formulario());
        formScroll.setBorder(null);
        formScroll.getVerticalScrollBar().setUnitIncrement(16);
        formScroll.setPreferredSize(new Dimension(440, 0));

        body.add(formScroll, BorderLayout.WEST);
        body.add(tabela(), BorderLayout.CENTER);
        page.add(body, BorderLayout.CENTER);
        return page;
    }

    private JPanel formulario() {
        JPanel form = Theme.card();
        form.setLayout(new GridBagLayout());
        form.setPreferredSize(new Dimension(410, 720));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets = new Insets(0, 0, 8, 0);
        int linha = 0;

        linha = adicionarCampo(form, gbc, linha, "Nome do projeto *", txtNome);
        linha = adicionarCampo(form, gbc, linha, "Descrição", new JScrollPane(txtDescricao));
        linha = adicionarCampo(form, gbc, linha, "Data de início * (AAAA-MM-DD)", txtInicio);
        linha = adicionarCampo(form, gbc, linha, "Término previsto (AAAA-MM-DD)", txtTermino);
        linha = adicionarCampo(form, gbc, linha, "Status", cbStatus);
        linha = adicionarCampo(form, gbc, linha, "Gerente responsável", cbGerente);

        listaEquipes.setFont(Theme.NORMAL);
        listaEquipes.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        listaEquipes.setVisibleRowCount(5);
        JScrollPane equipesScroll = new JScrollPane(listaEquipes);
        equipesScroll.setPreferredSize(new Dimension(350, 110));
        linha = adicionarCampo(form, gbc, linha, "Equipes participantes", equipesScroll);

        JLabel dica = new JLabel("Segure Ctrl para selecionar mais de uma equipe.");
        dica.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        dica.setForeground(Theme.MUTED);
        gbc.gridy = linha++;
        form.add(dica, gbc);

        linha = adicionarCampo(form, gbc, linha, "Entregável previsto", txtEntregavel);

        JButton salvar = Theme.primaryButton("Salvar projeto");
        JButton limpar = Theme.secondaryButton("Limpar");
        JButton excluir = Theme.secondaryButton("Excluir");
        salvar.addActionListener(e -> salvar());
        limpar.addActionListener(e -> limpar());
        excluir.addActionListener(e -> excluir());

        gbc.gridy = linha++;
        form.add(salvar, gbc);
        gbc.gridy = linha++;
        form.add(limpar, gbc);
        gbc.gridy = linha++;
        form.add(excluir, gbc);
        return form;
    }

    private int adicionarCampo(JPanel form, GridBagConstraints gbc, int linha, String rotulo, Component campo) {
        gbc.gridy = linha++;
        form.add(Theme.label(rotulo), gbc);
        gbc.gridy = linha++;
        form.add(campo, gbc);
        return linha;
    }

    private JScrollPane tabela() {
        tabela.setModel(new DefaultTableModel(new Object[]{"ID", "Nome", "Gerente", "Equipes", "Status", "Início", "Término", "Entregável"}, 0));
        tabela.getSelectionModel().addListSelectionListener(e -> selecionarLinha());
        return new JScrollPane(tabela);
    }

    private void carregarGerentes() {
        try {
            cbGerente.removeAllItems();
            for (Usuario u : new UsuarioDAO().listarGerentes()) {
                cbGerente.addItem(new ComboItem(u.getId(), u.getNomeCompleto()));
            }
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void carregarEquipes() {
        try {
            equipesModel.clear();
            for (Equipe e : new EquipeDAO().listar()) {
                equipesModel.addElement(new ComboItem(e.getId(), e.getNome()));
            }
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void carregarTabela() {
        try {
            DefaultTableModel model = (DefaultTableModel) tabela.getModel();
            model.setRowCount(0);
            List<Projeto> lista = dao.listar();
            for (Projeto p : lista) {
                model.addRow(new Object[]{p.getId(), p.getNome(), p.getGerenteNome(), p.getEquipesNomes(), p.getStatus(), p.getDataInicio(), p.getDataTerminoPrevista(), p.getEntregavelPrevisto()});
            }
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void selecionarLinha() {
        int row = tabela.getSelectedRow();
        if (row < 0) return;
        try {
            List<Projeto> lista = dao.listar();
            Projeto p = lista.get(row);
            idSelecionado = p.getId();
            txtNome.setText(p.getNome());
            txtDescricao.setText(p.getDescricao());
            txtInicio.setText(String.valueOf(p.getDataInicio()));
            txtTermino.setText(p.getDataTerminoPrevista() == null ? "" : String.valueOf(p.getDataTerminoPrevista()));
            cbStatus.setSelectedItem(p.getStatus());
            txtEntregavel.setText(p.getEntregavelPrevisto());
            selecionarCombo(cbGerente, p.getGerenteId());
            selecionarEquipes(dao.listarEquipeIdsDoProjeto(p.getId()));
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void selecionarCombo(JComboBox<ComboItem> combo, int id) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).getId() == id) combo.setSelectedIndex(i);
        }
    }

    private void selecionarEquipes(List<Integer> ids) {
        listaEquipes.clearSelection();
        for (int i = 0; i < equipesModel.size(); i++) {
            if (ids.contains(equipesModel.getElementAt(i).getId())) {
                listaEquipes.addSelectionInterval(i, i);
            }
        }
    }

    private List<Integer> equipesSelecionadas() {
        List<Integer> ids = new ArrayList<>();
        for (ComboItem item : listaEquipes.getSelectedValuesList()) {
            ids.add(item.getId());
        }
        return ids;
    }

    private void salvar() {
        if (txtNome.getText().trim().isEmpty() || txtInicio.getText().trim().isEmpty() || cbGerente.getSelectedItem() == null) {
            Theme.message(this, "Preencha nome, data de início e gerente.");
            return;
        }
        try {
            Projeto p = new Projeto();
            p.setId(idSelecionado);
            p.setNome(txtNome.getText().trim());
            p.setDescricao(txtDescricao.getText().trim());
            p.setDataInicio(LocalDate.parse(txtInicio.getText().trim()));
            p.setDataTerminoPrevista(txtTermino.getText().trim().isEmpty() ? null : LocalDate.parse(txtTermino.getText().trim()));
            p.setStatus(cbStatus.getSelectedItem().toString());
            p.setGerenteId(((ComboItem) cbGerente.getSelectedItem()).getId());
            p.setEntregavelPrevisto(txtEntregavel.getText().trim());
            int projetoId = idSelecionado;
            if (idSelecionado == 0) {
                projetoId = dao.salvar(p);
            } else {
                dao.atualizar(p);
            }
            dao.atualizarEquipes(projetoId, equipesSelecionadas());
            Theme.message(this, "Projeto salvo com sucesso.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void excluir() {
        if (idSelecionado == 0) {
            Theme.message(this, "Selecione um projeto para excluir.");
            return;
        }
        int op = JOptionPane.showConfirmDialog(this, "Deseja excluir este projeto?", "Confirmação", JOptionPane.YES_NO_OPTION);
        if (op != JOptionPane.YES_OPTION) return;
        try {
            dao.excluir(idSelecionado);
            Theme.message(this, "Projeto excluído.");
            limpar();
            carregarTabela();
            principal.mostrarDashboard();
        } catch (Exception ex) {
            Theme.error(this, ex);
        }
    }

    private void limpar() {
        idSelecionado = 0;
        txtNome.setText("");
        txtDescricao.setText("");
        txtInicio.setText("");
        txtTermino.setText("");
        txtEntregavel.setText("");
        cbStatus.setSelectedIndex(0);
        if (cbGerente.getItemCount() > 0) cbGerente.setSelectedIndex(0);
        listaEquipes.clearSelection();
        tabela.clearSelection();
    }
}
