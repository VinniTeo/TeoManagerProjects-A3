package com.mycompany.sistemaprojetos;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import view.TelaLogin;

public class SistemaProjetos {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new TelaLogin().setVisible(true);
        });
    }
}
